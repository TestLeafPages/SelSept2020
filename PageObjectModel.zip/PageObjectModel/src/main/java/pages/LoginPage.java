package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage(ChromeDriver driver) {
		
		this.driver = driver;
		
	}
	

	// actionElementName
	public LoginPage enterUserName(String username) throws InterruptedException {

		driver.findElementByName("USERNAME").sendKeys(username);
		Thread.sleep(5000);

		return this;
	}

	public LoginPage enterPassword(String password) {
		driver.findElementById("password").sendKeys(password);

		return this;
	}

	public HomePage clickLoginButton() {

		driver.findElementByClassName("decorativeSubmit").click();

		return new HomePage(driver);
	}

	public LoginPage clickLoginForInvalidData() {

		driver.findElementByClassName("decorativeSubmit").click();

		return this;
	}

	public void verifyErrorMessage() {
		boolean displayed = driver.findElementByXPath("//p[text()='The Following Errors Occurred:']").isDisplayed();

		if (displayed) {
			System.out.println("Error message is displayed");
		} else {
			System.out.println("Error message is not displayed");
		}

	}

}
