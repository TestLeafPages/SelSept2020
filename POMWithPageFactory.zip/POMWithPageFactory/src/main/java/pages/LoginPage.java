package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage(ChromeDriver driver) {
		
		this.driver = driver;
		
		//to initialize the elements
		PageFactory.initElements(driver, this);
		
	}
	
	@CacheLookup
	@FindBy(how = How.XPATH,using="//input") List<WebElement> listInputs;
	
	//AND condition
	/*
	 * @FindBys( {
	 * 
	 * @FindBy(how = How.ID,using="username123"),
	 * 
	 * @FindBy(how = How.XPATH,using="//input[@name='USERNAME']") } ) WebElement
	 * uName;
	 */
	
	//OR condition
	/*
	 * @FindAll( {
	 * 
	 * @FindBy(how = How.ID,using="username123"),
	 * 
	 * @FindBy(how = How.XPATH,using="//input[@name='USERNAME']") } ) WebElement
	 * uName;
	 */
	
	// actionElementName
	public LoginPage enterUserName(String username) throws InterruptedException {
		
		WebElement firstElement = listInputs.get(0);
		
		firstElement.sendKeys(username);
		return this;
	}
	
	@CacheLookup
	@FindBy(id="password") WebElement pWord;

	public LoginPage enterPassword(String password) {
		pWord.sendKeys(password);

		return this;
	}

	@FindBy(how = How.CLASS_NAME,using="decorativeSubmit") WebElement login;
	
	
	public HomePage clickLoginButton() {

		login.click();

		return new HomePage(driver);
	}

	public LoginPage clickLoginForInvalidData() {

		login.click();

		return this;
	}
	
	
	@FindBy(how = How.XPATH,using ="//p[text()='The Following Errors Occurred:']") WebElement errorMsg;

	public void verifyErrorMessage() {
		boolean displayed = errorMsg.isDisplayed();

		if (displayed) {
			System.out.println("Error message is displayed");
		} else {
			System.out.println("Error message is not displayed");
		}

	}

}
