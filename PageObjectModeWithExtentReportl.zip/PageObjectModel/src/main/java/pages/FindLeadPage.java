package pages;

public class FindLeadPage {
	
	public FindLeadPage enterFirstName() {
		
		System.out.println("enter first name");
		
		return this;

	}

}
