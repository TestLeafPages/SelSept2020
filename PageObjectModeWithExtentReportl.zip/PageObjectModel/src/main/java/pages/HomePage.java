package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	
	public HomePage(ChromeDriver driver) {
		
		this.driver = driver;
	}
	
	
	public LoginPage clickLogout() throws IOException {
		try {

			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("Logout button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Logout button not clicked successfully", "fail");
		}
		
		return new LoginPage(driver);
	}

}
